

//Defino Byte   
typedef unsigned char   byte;
typedef unsigned short  word;
typedef unsigned long   dword;
typedef unsigned long long qword;
typedef unsigned long long int ticks_t; //tipo para timer
